import Foundation

struct Constants {
    static let apiKey = "edab96b81362410b868cf1c2f0f7271b"
    static let baseURL = "https://api.spoonacular.com/recipes/complexSearch"
}
