import SwiftUI

@main
struct LetHimCookApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
